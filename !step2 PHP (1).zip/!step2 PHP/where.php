<?php
	session_start();
	include "header.php";
?>

	<main>
		<div class="content">

			<div class="head">Наши контакты</div>
			<p>Адрес: <b>ул. Уличная, д. 2</b></p>
			<p>Номер телефона: <b>71234567890</b></p>
			<p>Email: <b>gmail@gmail.com</b></p>
			
			<div class="head">Наше местоположение</div>
			<img src="images/map.jpg" alt="">

		</div>
	</main>

<?php include "footer.php" ?>