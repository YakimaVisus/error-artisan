	<footer>
		<div class="content">
			<ul>
				<?= $menu ?>
			</ul>
		</div>
	</footer>
	
</body>
</html>